# 🚀 Démarrage Rapide - Analyseur Ergonomique

## Installation et Utilisation

### Prérequis
- Python 3.8 ou supérieur
- Chrome ou Chromium
- Connexion Internet

### Démarrage Automatique

**Sur Windows:**
1. Double-cliquez sur `start.bat`
2. L'application se lancera automatiquement
3. Ouvrez http://localhost:5000 dans votre navigateur

**Sur Linux/Mac:**
1. Ouvrez un terminal dans ce dossier
2. Exécutez: `./start.sh`
3. Ouvrez http://localhost:5000 dans votre navigateur

### Démarrage Manuel
```bash
pip install -r requirements.txt
python run.py
```

### Utilisation
1. Entrez l'URL d'un site web (ex: google.com)
2. Cliquez sur "Analyser"
3. Consultez le rapport ergonomique

### Sites de Test Recommandés
- google.com
- github.com
- wikipedia.org
- example.com

## Support
Consultez README.md pour la documentation complète.
